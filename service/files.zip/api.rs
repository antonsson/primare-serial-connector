use std::sync::Arc;
use axum::{
    extract::{Path, State},
    routing::{get, post},
    Json, Router,
};
use serde::{Deserialize, Serialize};

use crate::error::ApiResult;
use crate::state::AppState;

pub fn routes() -> Router<Arc<AppState>> {
    Router::new()
        .route("/status",          get(get_status))
        .route("/power",           get(get_power).post(set_power))
        .route("/volume",          get(get_volume).post(set_volume))
        .route("/input",           get(get_input).post(set_input))
        .route("/mute",            get(get_mute).post(set_mute))
        .route("/balance",         get(get_balance).post(set_balance))
        .route("/dim",             get(get_dim).post(set_dim))
        .route("/menu",            post(menu_action))
        .route("/ir_input",        get(get_ir_input).post(set_ir_input))
        .route("/info",            get(get_info))
        .route("/input/current/name",      get(get_current_input_name))
        .route("/input/:id/name",  get(get_input_name))
        .route("/factory_reset",   post(factory_reset))
}

// ---- Status ----

#[derive(Serialize)]
pub struct StatusResponse {
    pub power: bool,
    pub volume: u8,
    pub input: u8,
    pub mute: bool,
    pub balance: i8,
    pub dim: u8,
}

async fn get_status(State(state): State<Arc<AppState>>) -> ApiResult<Json<StatusResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(StatusResponse {
        power:   s.get_power().await?,
        volume:  s.get_volume().await?,
        input:   s.get_input().await?,
        mute:    s.get_mute().await?,
        balance: s.get_balance().await?,
        dim:     s.get_dim().await?,
    }))
}

// ---- Power ----

#[derive(Serialize)]
pub struct PowerResponse {
    pub power: bool,
}

#[derive(Deserialize)]
pub struct PowerRequest {
    /// "on", "off", or "toggle"
    pub state: String,
}

async fn get_power(State(state): State<Arc<AppState>>) -> ApiResult<Json<PowerResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(PowerResponse { power: s.get_power().await? }))
}

async fn set_power(
    State(state): State<Arc<AppState>>,
    Json(body): Json<PowerRequest>,
) -> ApiResult<Json<PowerResponse>> {
    let mut s = state.serial.lock().await;
    let power = match body.state.to_lowercase().as_str() {
        "on"     => s.set_power(true).await?,
        "off"    => s.set_power(false).await?,
        "toggle" => s.toggle_power().await?,
        other    => return Err(crate::error::AppError::InvalidParameter(
            format!("Unknown power state '{}'. Use on/off/toggle", other)
        )),
    };
    Ok(Json(PowerResponse { power }))
}

// ---- Volume ----

#[derive(Serialize)]
pub struct VolumeResponse {
    pub volume: u8,
}

#[derive(Deserialize)]
pub struct VolumeRequest {
    /// Absolute level 0-79
    pub level: Option<u8>,
    /// Relative step: +1 or -1
    pub step: Option<i8>,
}

async fn get_volume(State(state): State<Arc<AppState>>) -> ApiResult<Json<VolumeResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(VolumeResponse { volume: s.get_volume().await? }))
}

async fn set_volume(
    State(state): State<Arc<AppState>>,
    Json(body): Json<VolumeRequest>,
) -> ApiResult<Json<VolumeResponse>> {
    let mut s = state.serial.lock().await;
    let volume = match (body.level, body.step) {
        (Some(level), _) => s.set_volume(level).await?,
        (_, Some(step))  => s.step_volume(step > 0).await?,
        _ => return Err(crate::error::AppError::InvalidParameter(
            "Provide either 'level' (0-79) or 'step' (+1/-1)".into()
        )),
    };
    Ok(Json(VolumeResponse { volume }))
}

// ---- Input ----

#[derive(Serialize)]
pub struct InputResponse {
    pub input: u8,
}

#[derive(Deserialize)]
pub struct InputRequest {
    /// Direct input 1-7
    pub input: Option<u8>,
    /// "up" or "down"
    pub step: Option<String>,
}

async fn get_input(State(state): State<Arc<AppState>>) -> ApiResult<Json<InputResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(InputResponse { input: s.get_input().await? }))
}

async fn set_input(
    State(state): State<Arc<AppState>>,
    Json(body): Json<InputRequest>,
) -> ApiResult<Json<InputResponse>> {
    let mut s = state.serial.lock().await;
    let input = match (body.input, body.step.as_deref()) {
        (Some(i), _)     => s.set_input(i).await?,
        (_, Some("up"))  => s.step_input(true).await?,
        (_, Some("down"))=> s.step_input(false).await?,
        _ => return Err(crate::error::AppError::InvalidParameter(
            "Provide either 'input' (1-7) or 'step' (up/down)".into()
        )),
    };
    Ok(Json(InputResponse { input }))
}

// ---- Mute ----

#[derive(Serialize)]
pub struct MuteResponse {
    pub mute: bool,
}

#[derive(Deserialize)]
pub struct MuteRequest {
    /// true, false, or null for toggle
    pub state: Option<bool>,
}

async fn get_mute(State(state): State<Arc<AppState>>) -> ApiResult<Json<MuteResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(MuteResponse { mute: s.get_mute().await? }))
}

async fn set_mute(
    State(state): State<Arc<AppState>>,
    Json(body): Json<MuteRequest>,
) -> ApiResult<Json<MuteResponse>> {
    let mut s = state.serial.lock().await;
    let mute = match body.state {
        Some(v) => s.set_mute(v).await?,
        None    => s.toggle_mute().await?,
    };
    Ok(Json(MuteResponse { mute }))
}

// ---- Balance ----

#[derive(Serialize)]
pub struct BalanceResponse {
    pub balance: i8,
}

#[derive(Deserialize)]
pub struct BalanceRequest {
    /// Direct value -9 to +9
    pub value: Option<i8>,
    /// Relative step
    pub step: Option<i8>,
}

async fn get_balance(State(state): State<Arc<AppState>>) -> ApiResult<Json<BalanceResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(BalanceResponse { balance: s.get_balance().await? }))
}

async fn set_balance(
    State(state): State<Arc<AppState>>,
    Json(body): Json<BalanceRequest>,
) -> ApiResult<Json<BalanceResponse>> {
    let mut s = state.serial.lock().await;
    let balance = match (body.value, body.step) {
        (Some(v), _) => s.set_balance(v).await?,
        (_, Some(s_)) => s.step_balance(s_).await?,
        _ => return Err(crate::error::AppError::InvalidParameter(
            "Provide either 'value' (-9..9) or 'step'".into()
        )),
    };
    Ok(Json(BalanceResponse { balance }))
}

// ---- Dim ----

#[derive(Serialize)]
pub struct DimResponse {
    /// 0=off, 1-3=brightness levels
    pub dim: u8,
}

#[derive(Deserialize)]
pub struct DimRequest {
    /// Direct level 0-3
    pub level: Option<u8>,
    /// true = step to next level
    pub step: Option<bool>,
}

async fn get_dim(State(state): State<Arc<AppState>>) -> ApiResult<Json<DimResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(DimResponse { dim: s.get_dim().await? }))
}

async fn set_dim(
    State(state): State<Arc<AppState>>,
    Json(body): Json<DimRequest>,
) -> ApiResult<Json<DimResponse>> {
    let mut s = state.serial.lock().await;
    let dim = match (body.level, body.step) {
        (Some(l), _)        => s.set_dim(l).await?,
        (_, Some(true))     => s.step_dim().await?,
        _ => return Err(crate::error::AppError::InvalidParameter(
            "Provide either 'level' (0-3) or 'step': true".into()
        )),
    };
    Ok(Json(DimResponse { dim }))
}

// ---- Menu ----

#[derive(Deserialize)]
pub struct MenuRequest {
    /// "enter", "exit", "up", "down", "left", "right"
    pub action: String,
}

#[derive(Serialize)]
pub struct OkResponse {
    pub ok: bool,
}

async fn menu_action(
    State(state): State<Arc<AppState>>,
    Json(body): Json<MenuRequest>,
) -> ApiResult<Json<OkResponse>> {
    let mut s = state.serial.lock().await;
    // IR remote values for navigation (from Part 1 of spec)
    match body.action.to_lowercase().as_str() {
        "enter" => s.menu_enter().await?,
        "exit"  => s.menu_exit().await?,
        "up"    => s.menu_nav(0x1E).await?,  // Step up IR value = 30
        "down"  => s.menu_nav(0x1F).await?,  // Step down IR value = 31
        "right" => s.menu_nav(0x08).await?,  // Arrow right IR value = 8
        "left"  => s.menu_nav(0x09).await?,  // Arrow left IR value = 9
        other   => return Err(crate::error::AppError::InvalidParameter(
            format!("Unknown menu action '{}'. Use enter/exit/up/down/left/right", other)
        )),
    }
    Ok(Json(OkResponse { ok: true }))
}

// ---- IR Input ----

#[derive(Serialize)]
pub struct IrInputResponse {
    /// "front" or "back"
    pub source: String,
}

#[derive(Deserialize)]
pub struct IrInputRequest {
    pub source: String,
}

async fn get_ir_input(State(state): State<Arc<AppState>>) -> ApiResult<Json<IrInputResponse>> {
    let mut s = state.serial.lock().await;
    let back = s.get_ir_input().await?;
    Ok(Json(IrInputResponse { source: if back { "back".into() } else { "front".into() } }))
}

async fn set_ir_input(
    State(state): State<Arc<AppState>>,
    Json(body): Json<IrInputRequest>,
) -> ApiResult<Json<IrInputResponse>> {
    let mut s = state.serial.lock().await;
    let back = match body.source.to_lowercase().as_str() {
        "back"  => s.set_ir_input(true).await?,
        "front" => s.set_ir_input(false).await?,
        other   => return Err(crate::error::AppError::InvalidParameter(
            format!("Unknown IR source '{}'. Use front/back", other)
        )),
    };
    Ok(Json(IrInputResponse { source: if back { "back".into() } else { "front".into() } }))
}

// ---- Info ----

#[derive(Serialize)]
pub struct InfoResponse {
    pub product_line: String,
    pub model: String,
    pub firmware: String,
}

async fn get_info(State(state): State<Arc<AppState>>) -> ApiResult<Json<InfoResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(InfoResponse {
        product_line: s.get_product_line().await?,
        model:        s.get_model_name().await?,
        firmware:     s.get_version().await?,
    }))
}

// ---- Input names ----

#[derive(Serialize)]
pub struct InputNameResponse {
    pub name: String,
}

async fn get_current_input_name(State(state): State<Arc<AppState>>) -> ApiResult<Json<InputNameResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(InputNameResponse { name: s.get_input_name_current().await? }))
}

async fn get_input_name(
    State(state): State<Arc<AppState>>,
    Path(id): Path<u8>,
) -> ApiResult<Json<InputNameResponse>> {
    let mut s = state.serial.lock().await;
    Ok(Json(InputNameResponse { name: s.get_input_name(id).await? }))
}

// ---- Factory reset ----

#[derive(Deserialize)]
pub struct FactoryResetRequest {
    pub confirm: bool,
}

async fn factory_reset(
    State(state): State<Arc<AppState>>,
    Json(body): Json<FactoryResetRequest>,
) -> ApiResult<Json<OkResponse>> {
    if !body.confirm {
        return Err(crate::error::AppError::InvalidParameter(
            "Set 'confirm': true to proceed with factory reset".into()
        ));
    }
    let mut s = state.serial.lock().await;
    s.factory_reset().await?;
    Ok(Json(OkResponse { ok: true }))
}
