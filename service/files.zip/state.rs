use tokio::sync::Mutex;
use crate::serial::SerialConnection;

pub struct AppState {
    pub serial: Mutex<SerialConnection>,
}
